package com.milanwittpohl.playgroundwebbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaygroundWebBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaygroundWebBackendApplication.class, args);
	}

}
